﻿namespace QL_KHACHSAN
{
    partial class frmHOADON
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnThoatphong = new System.Windows.Forms.Button();
            this.btnXoaphong = new System.Windows.Forms.Button();
            this.btnSuaphong = new System.Windows.Forms.Button();
            this.btnLuuphong = new System.Windows.Forms.Button();
            this.btnThemphong = new System.Windows.Forms.Button();
            this.txtMAPHONG = new System.Windows.Forms.TextBox();
            this.txtGIOVAO = new System.Windows.Forms.TextBox();
            this.txtSOCMND = new System.Windows.Forms.TextBox();
            this.txtMANV = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMAHD = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvHOADON = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btnThanhtoan = new System.Windows.Forms.Button();
            this.btnTim4 = new System.Windows.Forms.Button();
            this.btnTimTheoPhong = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHOADON)).BeginInit();
            this.SuspendLayout();
            // 
            // btnThoatphong
            // 
            this.btnThoatphong.Location = new System.Drawing.Point(174, 258);
            this.btnThoatphong.Name = "btnThoatphong";
            this.btnThoatphong.Size = new System.Drawing.Size(75, 23);
            this.btnThoatphong.TabIndex = 34;
            this.btnThoatphong.Text = "Thoát";
            this.btnThoatphong.UseVisualStyleBackColor = true;
            this.btnThoatphong.Click += new System.EventHandler(this.btnThoatphong_Click);
            // 
            // btnXoaphong
            // 
            this.btnXoaphong.Location = new System.Drawing.Point(174, 216);
            this.btnXoaphong.Name = "btnXoaphong";
            this.btnXoaphong.Size = new System.Drawing.Size(75, 23);
            this.btnXoaphong.TabIndex = 35;
            this.btnXoaphong.Text = "Xóa";
            this.btnXoaphong.UseVisualStyleBackColor = true;
            this.btnXoaphong.Click += new System.EventHandler(this.btnXoaphong_Click);
            // 
            // btnSuaphong
            // 
            this.btnSuaphong.Location = new System.Drawing.Point(93, 216);
            this.btnSuaphong.Name = "btnSuaphong";
            this.btnSuaphong.Size = new System.Drawing.Size(75, 23);
            this.btnSuaphong.TabIndex = 36;
            this.btnSuaphong.Text = "Sửa";
            this.btnSuaphong.UseVisualStyleBackColor = true;
            // 
            // btnLuuphong
            // 
            this.btnLuuphong.Location = new System.Drawing.Point(12, 258);
            this.btnLuuphong.Name = "btnLuuphong";
            this.btnLuuphong.Size = new System.Drawing.Size(75, 23);
            this.btnLuuphong.TabIndex = 37;
            this.btnLuuphong.Text = "Lưu";
            this.btnLuuphong.UseVisualStyleBackColor = true;
            // 
            // btnThemphong
            // 
            this.btnThemphong.Location = new System.Drawing.Point(12, 216);
            this.btnThemphong.Name = "btnThemphong";
            this.btnThemphong.Size = new System.Drawing.Size(75, 23);
            this.btnThemphong.TabIndex = 38;
            this.btnThemphong.Text = "Thêm";
            this.btnThemphong.UseVisualStyleBackColor = true;
            // 
            // txtMAPHONG
            // 
            this.txtMAPHONG.Location = new System.Drawing.Point(155, 175);
            this.txtMAPHONG.Name = "txtMAPHONG";
            this.txtMAPHONG.Size = new System.Drawing.Size(100, 20);
            this.txtMAPHONG.TabIndex = 29;
            // 
            // txtGIOVAO
            // 
            this.txtGIOVAO.Location = new System.Drawing.Point(155, 148);
            this.txtGIOVAO.Name = "txtGIOVAO";
            this.txtGIOVAO.Size = new System.Drawing.Size(100, 20);
            this.txtGIOVAO.TabIndex = 31;
            // 
            // txtSOCMND
            // 
            this.txtSOCMND.Location = new System.Drawing.Point(155, 120);
            this.txtSOCMND.Name = "txtSOCMND";
            this.txtSOCMND.Size = new System.Drawing.Size(100, 20);
            this.txtSOCMND.TabIndex = 30;
            // 
            // txtMANV
            // 
            this.txtMANV.Location = new System.Drawing.Point(155, 89);
            this.txtMANV.Name = "txtMANV";
            this.txtMANV.Size = new System.Drawing.Size(100, 20);
            this.txtMANV.TabIndex = 32;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(64, 178);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 24;
            this.label7.Text = "Mã phòng:";
            // 
            // txtMAHD
            // 
            this.txtMAHD.Location = new System.Drawing.Point(155, 58);
            this.txtMAHD.Name = "txtMAHD";
            this.txtMAHD.Size = new System.Drawing.Size(100, 20);
            this.txtMAHD.TabIndex = 33;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(64, 151);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 26;
            this.label6.Text = "Giờ vào:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(64, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 13);
            this.label5.TabIndex = 23;
            this.label5.Text = "Mã khách hàng:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(64, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 13);
            this.label3.TabIndex = 27;
            this.label3.Text = "Mã nhân viên:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(64, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 28;
            this.label2.Text = "Mã hóa đơn:";
            // 
            // dgvHOADON
            // 
            this.dgvHOADON.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHOADON.Location = new System.Drawing.Point(369, 59);
            this.dgvHOADON.Name = "dgvHOADON";
            this.dgvHOADON.Size = new System.Drawing.Size(419, 227);
            this.dgvHOADON.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mistral", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(258, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 48);
            this.label1.TabIndex = 21;
            this.label1.Text = "HÓA ĐƠN";
            // 
            // btnThanhtoan
            // 
            this.btnThanhtoan.Location = new System.Drawing.Point(93, 258);
            this.btnThanhtoan.Name = "btnThanhtoan";
            this.btnThanhtoan.Size = new System.Drawing.Size(75, 23);
            this.btnThanhtoan.TabIndex = 37;
            this.btnThanhtoan.Text = "Thanh toán";
            this.btnThanhtoan.UseVisualStyleBackColor = true;
            // 
            // btnTim4
            // 
            this.btnTim4.Location = new System.Drawing.Point(266, 216);
            this.btnTim4.Name = "btnTim4";
            this.btnTim4.Size = new System.Drawing.Size(75, 23);
            this.btnTim4.TabIndex = 35;
            this.btnTim4.Text = "Tìm";
            this.btnTim4.UseVisualStyleBackColor = true;
            this.btnTim4.Click += new System.EventHandler(this.btnTim4_Click);
            // 
            // btnTimTheoPhong
            // 
            this.btnTimTheoPhong.Location = new System.Drawing.Point(266, 258);
            this.btnTimTheoPhong.Name = "btnTimTheoPhong";
            this.btnTimTheoPhong.Size = new System.Drawing.Size(75, 23);
            this.btnTimTheoPhong.TabIndex = 35;
            this.btnTimTheoPhong.Text = "KT Phòng";
            this.btnTimTheoPhong.UseVisualStyleBackColor = true;
            this.btnTimTheoPhong.Click += new System.EventHandler(this.btnXoaphong_Click);
            // 
            // frmHOADON
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 293);
            this.Controls.Add(this.btnThoatphong);
            this.Controls.Add(this.btnTim4);
            this.Controls.Add(this.btnTimTheoPhong);
            this.Controls.Add(this.btnXoaphong);
            this.Controls.Add(this.btnSuaphong);
            this.Controls.Add(this.btnThanhtoan);
            this.Controls.Add(this.btnLuuphong);
            this.Controls.Add(this.btnThemphong);
            this.Controls.Add(this.txtMAPHONG);
            this.Controls.Add(this.txtGIOVAO);
            this.Controls.Add(this.txtSOCMND);
            this.Controls.Add(this.txtMANV);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtMAHD);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvHOADON);
            this.Controls.Add(this.label1);
            this.Name = "frmHOADON";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hóa đơn";
            this.Load += new System.EventHandler(this.frmHOADON_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHOADON)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnThoatphong;
        private System.Windows.Forms.Button btnXoaphong;
        private System.Windows.Forms.Button btnSuaphong;
        private System.Windows.Forms.Button btnLuuphong;
        private System.Windows.Forms.Button btnThemphong;
        private System.Windows.Forms.TextBox txtMAPHONG;
        private System.Windows.Forms.TextBox txtGIOVAO;
        private System.Windows.Forms.TextBox txtSOCMND;
        private System.Windows.Forms.TextBox txtMANV;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtMAHD;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvHOADON;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnThanhtoan;
        private System.Windows.Forms.Button btnTim4;
        private System.Windows.Forms.Button btnTimTheoPhong;
    }
}