﻿namespace QL_KHACHSAN
{
    partial class frmDSNHANVIEN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnThoatphong = new System.Windows.Forms.Button();
            this.btnXoaNhanVien = new System.Windows.Forms.Button();
            this.btnSuaNhanvien = new System.Windows.Forms.Button();
            this.btnLuuNhanVien = new System.Windows.Forms.Button();
            this.btnThemNhanVien = new System.Windows.Forms.Button();
            this.txtDIACHI = new System.Windows.Forms.TextBox();
            this.txtTENNV = new System.Windows.Forms.TextBox();
            this.txtMANV = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvDSNHANVIEN = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.txtNGAYSINH = new System.Windows.Forms.TextBox();
            this.cmbGIOITINH = new System.Windows.Forms.ComboBox();
            this.btnTimNhanVien = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSNHANVIEN)).BeginInit();
            this.SuspendLayout();
            // 
            // btnThoatphong
            // 
            this.btnThoatphong.Location = new System.Drawing.Point(212, 266);
            this.btnThoatphong.Name = "btnThoatphong";
            this.btnThoatphong.Size = new System.Drawing.Size(75, 23);
            this.btnThoatphong.TabIndex = 15;
            this.btnThoatphong.Text = "Thoát";
            this.btnThoatphong.UseVisualStyleBackColor = true;
            this.btnThoatphong.Click += new System.EventHandler(this.btnThoatphong_Click);
            // 
            // btnXoaNhanVien
            // 
            this.btnXoaNhanVien.Location = new System.Drawing.Point(212, 224);
            this.btnXoaNhanVien.Name = "btnXoaNhanVien";
            this.btnXoaNhanVien.Size = new System.Drawing.Size(75, 23);
            this.btnXoaNhanVien.TabIndex = 16;
            this.btnXoaNhanVien.Text = "Xóa";
            this.btnXoaNhanVien.UseVisualStyleBackColor = true;
            // 
            // btnSuaNhanvien
            // 
            this.btnSuaNhanvien.Location = new System.Drawing.Point(131, 224);
            this.btnSuaNhanvien.Name = "btnSuaNhanvien";
            this.btnSuaNhanvien.Size = new System.Drawing.Size(75, 23);
            this.btnSuaNhanvien.TabIndex = 17;
            this.btnSuaNhanvien.Text = "Sửa";
            this.btnSuaNhanvien.UseVisualStyleBackColor = true;
            // 
            // btnLuuNhanVien
            // 
            this.btnLuuNhanVien.Location = new System.Drawing.Point(50, 266);
            this.btnLuuNhanVien.Name = "btnLuuNhanVien";
            this.btnLuuNhanVien.Size = new System.Drawing.Size(75, 23);
            this.btnLuuNhanVien.TabIndex = 18;
            this.btnLuuNhanVien.Text = "Lưu";
            this.btnLuuNhanVien.UseVisualStyleBackColor = true;
            // 
            // btnThemNhanVien
            // 
            this.btnThemNhanVien.Location = new System.Drawing.Point(50, 224);
            this.btnThemNhanVien.Name = "btnThemNhanVien";
            this.btnThemNhanVien.Size = new System.Drawing.Size(75, 23);
            this.btnThemNhanVien.TabIndex = 19;
            this.btnThemNhanVien.Text = "Thêm";
            this.btnThemNhanVien.UseVisualStyleBackColor = true;
            this.btnThemNhanVien.Click += new System.EventHandler(this.btnThemphong_Click);
            // 
            // txtDIACHI
            // 
            this.txtDIACHI.Location = new System.Drawing.Point(131, 147);
            this.txtDIACHI.Name = "txtDIACHI";
            this.txtDIACHI.Size = new System.Drawing.Size(100, 20);
            this.txtDIACHI.TabIndex = 11;
            // 
            // txtTENNV
            // 
            this.txtTENNV.Location = new System.Drawing.Point(131, 92);
            this.txtTENNV.Name = "txtTENNV";
            this.txtTENNV.Size = new System.Drawing.Size(100, 20);
            this.txtTENNV.TabIndex = 13;
            // 
            // txtMANV
            // 
            this.txtMANV.Location = new System.Drawing.Point(131, 61);
            this.txtMANV.Name = "txtMANV";
            this.txtMANV.Size = new System.Drawing.Size(100, 20);
            this.txtMANV.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(53, 150);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Địa chỉ:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(53, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Giới tính:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Tên nhân viên:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(53, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Mã nhân viên:";
            // 
            // dgvDSNHANVIEN
            // 
            this.dgvDSNHANVIEN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSNHANVIEN.Location = new System.Drawing.Point(310, 61);
            this.dgvDSNHANVIEN.Name = "dgvDSNHANVIEN";
            this.dgvDSNHANVIEN.Size = new System.Drawing.Size(419, 227);
            this.dgvDSNHANVIEN.TabIndex = 6;
            this.dgvDSNHANVIEN.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDSNHANVIEN_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mistral", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(247, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(362, 48);
            this.label1.TabIndex = 5;
            this.label1.Text = "DANH SÁCH NHÂN VIÊN";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(53, 174);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Số điện thoại:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(53, 201);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Ngày sinh:";
            // 
            // txtSDT
            // 
            this.txtSDT.Location = new System.Drawing.Point(131, 171);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(100, 20);
            this.txtSDT.TabIndex = 12;
            // 
            // txtNGAYSINH
            // 
            this.txtNGAYSINH.Location = new System.Drawing.Point(131, 198);
            this.txtNGAYSINH.Name = "txtNGAYSINH";
            this.txtNGAYSINH.Size = new System.Drawing.Size(100, 20);
            this.txtNGAYSINH.TabIndex = 11;
            // 
            // cmbGIOITINH
            // 
            this.cmbGIOITINH.FormattingEnabled = true;
            this.cmbGIOITINH.Items.AddRange(new object[] {
            "tất cả",
            "Nam",
            "Nữ"});
            this.cmbGIOITINH.Location = new System.Drawing.Point(131, 119);
            this.cmbGIOITINH.Name = "cmbGIOITINH";
            this.cmbGIOITINH.Size = new System.Drawing.Size(100, 21);
            this.cmbGIOITINH.TabIndex = 20;
            this.cmbGIOITINH.SelectedIndexChanged += new System.EventHandler(this.cmbGIOITINH_SelectedIndexChanged);
            // 
            // btnTimNhanVien
            // 
            this.btnTimNhanVien.Location = new System.Drawing.Point(131, 266);
            this.btnTimNhanVien.Name = "btnTimNhanVien";
            this.btnTimNhanVien.Size = new System.Drawing.Size(75, 23);
            this.btnTimNhanVien.TabIndex = 17;
            this.btnTimNhanVien.Text = "Tìm";
            this.btnTimNhanVien.UseVisualStyleBackColor = true;
            this.btnTimNhanVien.Click += new System.EventHandler(this.btnTim2_Click);
            // 
            // frmDSNHANVIEN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(778, 311);
            this.Controls.Add(this.cmbGIOITINH);
            this.Controls.Add(this.btnThoatphong);
            this.Controls.Add(this.btnXoaNhanVien);
            this.Controls.Add(this.btnTimNhanVien);
            this.Controls.Add(this.btnSuaNhanvien);
            this.Controls.Add(this.btnLuuNhanVien);
            this.Controls.Add(this.btnThemNhanVien);
            this.Controls.Add(this.txtNGAYSINH);
            this.Controls.Add(this.txtSDT);
            this.Controls.Add(this.txtDIACHI);
            this.Controls.Add(this.txtTENNV);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtMANV);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvDSNHANVIEN);
            this.Controls.Add(this.label1);
            this.Name = "frmDSNHANVIEN";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh sách Nhân viên";
            this.Load += new System.EventHandler(this.frmDSNHANVIEN_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSNHANVIEN)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnThoatphong;
        private System.Windows.Forms.Button btnXoaNhanVien;
        private System.Windows.Forms.Button btnSuaNhanvien;
        private System.Windows.Forms.Button btnLuuNhanVien;
        private System.Windows.Forms.Button btnThemNhanVien;
        private System.Windows.Forms.TextBox txtDIACHI;
        private System.Windows.Forms.TextBox txtTENNV;
        private System.Windows.Forms.TextBox txtMANV;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvDSNHANVIEN;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.TextBox txtNGAYSINH;
        private System.Windows.Forms.ComboBox cmbGIOITINH;
        private System.Windows.Forms.Button btnTimNhanVien;
    }
}