﻿namespace QL_KHACHSAN
{
    partial class frmDSKHACHHANG
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnThoatphong = new System.Windows.Forms.Button();
            this.btnXoaphong = new System.Windows.Forms.Button();
            this.btnSuaphong = new System.Windows.Forms.Button();
            this.btnLuuphong = new System.Windows.Forms.Button();
            this.btnThemphong = new System.Windows.Forms.Button();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.txtDIACHI = new System.Windows.Forms.TextBox();
            this.txtHOTEN = new System.Windows.Forms.TextBox();
            this.txtSOCMND = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvDSKHACHHANG = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btnTim3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSKHACHHANG)).BeginInit();
            this.SuspendLayout();
            // 
            // btnThoatphong
            // 
            this.btnThoatphong.Location = new System.Drawing.Point(210, 238);
            this.btnThoatphong.Name = "btnThoatphong";
            this.btnThoatphong.Size = new System.Drawing.Size(75, 23);
            this.btnThoatphong.TabIndex = 34;
            this.btnThoatphong.Text = "Thoát";
            this.btnThoatphong.UseVisualStyleBackColor = true;
            this.btnThoatphong.Click += new System.EventHandler(this.btnThoatphong_Click);
            // 
            // btnXoaphong
            // 
            this.btnXoaphong.Location = new System.Drawing.Point(210, 196);
            this.btnXoaphong.Name = "btnXoaphong";
            this.btnXoaphong.Size = new System.Drawing.Size(75, 23);
            this.btnXoaphong.TabIndex = 35;
            this.btnXoaphong.Text = "Xóa";
            this.btnXoaphong.UseVisualStyleBackColor = true;
            // 
            // btnSuaphong
            // 
            this.btnSuaphong.Location = new System.Drawing.Point(129, 196);
            this.btnSuaphong.Name = "btnSuaphong";
            this.btnSuaphong.Size = new System.Drawing.Size(75, 23);
            this.btnSuaphong.TabIndex = 36;
            this.btnSuaphong.Text = "Sửa";
            this.btnSuaphong.UseVisualStyleBackColor = true;
            // 
            // btnLuuphong
            // 
            this.btnLuuphong.Location = new System.Drawing.Point(48, 238);
            this.btnLuuphong.Name = "btnLuuphong";
            this.btnLuuphong.Size = new System.Drawing.Size(75, 23);
            this.btnLuuphong.TabIndex = 37;
            this.btnLuuphong.Text = "Lưu";
            this.btnLuuphong.UseVisualStyleBackColor = true;
            // 
            // btnThemphong
            // 
            this.btnThemphong.Location = new System.Drawing.Point(48, 196);
            this.btnThemphong.Name = "btnThemphong";
            this.btnThemphong.Size = new System.Drawing.Size(75, 23);
            this.btnThemphong.TabIndex = 38;
            this.btnThemphong.Text = "Thêm";
            this.btnThemphong.UseVisualStyleBackColor = true;
            // 
            // txtSDT
            // 
            this.txtSDT.Location = new System.Drawing.Point(149, 147);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(100, 20);
            this.txtSDT.TabIndex = 30;
            // 
            // txtDIACHI
            // 
            this.txtDIACHI.Location = new System.Drawing.Point(149, 123);
            this.txtDIACHI.Name = "txtDIACHI";
            this.txtDIACHI.Size = new System.Drawing.Size(100, 20);
            this.txtDIACHI.TabIndex = 29;
            // 
            // txtHOTEN
            // 
            this.txtHOTEN.Location = new System.Drawing.Point(149, 97);
            this.txtHOTEN.Name = "txtHOTEN";
            this.txtHOTEN.Size = new System.Drawing.Size(100, 20);
            this.txtHOTEN.TabIndex = 32;
            // 
            // txtSOCMND
            // 
            this.txtSOCMND.Location = new System.Drawing.Point(149, 66);
            this.txtSOCMND.Name = "txtSOCMND";
            this.txtSOCMND.Size = new System.Drawing.Size(100, 20);
            this.txtSOCMND.TabIndex = 33;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(53, 147);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "Số điện thoại:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(53, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 22;
            this.label5.Text = "Địa chỉ:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 26;
            this.label3.Text = "Tên khách hàng:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(53, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 27;
            this.label2.Text = "Số CMND:";
            // 
            // dgvDSKHACHHANG
            // 
            this.dgvDSKHACHHANG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSKHACHHANG.Location = new System.Drawing.Point(310, 63);
            this.dgvDSKHACHHANG.Name = "dgvDSKHACHHANG";
            this.dgvDSKHACHHANG.Size = new System.Drawing.Size(419, 227);
            this.dgvDSKHACHHANG.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mistral", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(247, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(393, 48);
            this.label1.TabIndex = 20;
            this.label1.Text = "DANH SÁCH KHÁCH HÀNG";
            // 
            // btnTim3
            // 
            this.btnTim3.Location = new System.Drawing.Point(129, 238);
            this.btnTim3.Name = "btnTim3";
            this.btnTim3.Size = new System.Drawing.Size(75, 23);
            this.btnTim3.TabIndex = 36;
            this.btnTim3.Text = "Tìm";
            this.btnTim3.UseVisualStyleBackColor = true;
            this.btnTim3.Click += new System.EventHandler(this.btnTim3_Click);
            // 
            // frmDSKHACHHANG
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(779, 302);
            this.Controls.Add(this.btnThoatphong);
            this.Controls.Add(this.btnXoaphong);
            this.Controls.Add(this.btnTim3);
            this.Controls.Add(this.btnSuaphong);
            this.Controls.Add(this.btnLuuphong);
            this.Controls.Add(this.btnThemphong);
            this.Controls.Add(this.txtSDT);
            this.Controls.Add(this.txtDIACHI);
            this.Controls.Add(this.txtHOTEN);
            this.Controls.Add(this.txtSOCMND);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvDSKHACHHANG);
            this.Controls.Add(this.label1);
            this.Name = "frmDSKHACHHANG";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh sách Khách hàng";
            this.Load += new System.EventHandler(this.frmDSKHACHHANG_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSKHACHHANG)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnThoatphong;
        private System.Windows.Forms.Button btnXoaphong;
        private System.Windows.Forms.Button btnSuaphong;
        private System.Windows.Forms.Button btnLuuphong;
        private System.Windows.Forms.Button btnThemphong;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.TextBox txtDIACHI;
        private System.Windows.Forms.TextBox txtHOTEN;
        private System.Windows.Forms.TextBox txtSOCMND;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvDSKHACHHANG;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnTim3;
    }
}